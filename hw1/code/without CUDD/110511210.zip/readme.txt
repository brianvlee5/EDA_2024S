The makefile is in the same directory as the other source code files.
Type "make" in the terminal to compile the codes, the executable will be in the same directory as the makefile.
Type "./Lab01 case1.txt ans1.txt" to run the program. (1 is for example, you can change the number)

