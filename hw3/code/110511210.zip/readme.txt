use "make" in the directory of makefile to compile code
use "./Lab3 [input.in] [output file]" to run the program 
